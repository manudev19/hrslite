<?php 
$prodName = 'Sun Technologies, Inc';
$copyrightYear = date('Y');

?>
For any help email us at <a href="mailto:support.hrm@suntechnologies.com">support.hrm@suntechnologies.com</a><br><br>
<?php echo $prodName;?><br/><br>
&copy; <?php echo $copyrightYear;?> <a href="http://suntechnologies.com/" target="_blank">Sun Technologies, Inc</a>. All rights reserved.

