<?php
$imagePath = theme_path("images/login");
?>
<div id="footer" >
    <div>
      <?php include_partial('global/copyright'); ?>
    </div>
</div>
